package ja.co.internous.ecsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
