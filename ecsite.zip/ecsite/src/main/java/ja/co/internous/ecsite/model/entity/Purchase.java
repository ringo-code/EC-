	package ja.co.internous.ecsite.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
	@Table(name="purchase")
    public class Purchase {

		@Id
		@Column(name="id")
		@GeneratedValue(strategy=GenerationType. IDENTITY)
		private long id;

		@Column(name= "user_id")
		private long useId;

		@Column(name= "goods_id")
		private long goods_Id;

		@Column(name= "goods_name")
		private String goodsName;

		@Column(name= "item_count")
		private long itemCount;

		@Column(name= "total")
		private long total;

		@Column(name= "created_at")
		private java.sql.Timestamp createdAt;


		public long getId( ) {
			return id;
			}

			public void setId(long id) {
			this.id = id;
			}

			public long getUserId() {
			return useId;
			}

			public void setUserId(long userId) {
			this.useId = userId;
			}

			public long getGoodsId() {
			return goods_Id;
			}

			public void setGoodsId(int goodsId) {
			this.goods_Id = goodsId;
			}

			public String getGoodsName() {
			return goodsName;
			}

			public void setGoodslName(String goodsName) {
			this.goodsName = goodsName;
			}

			public long getItemCount() {
			return itemCount;
			}

			public void setItemCount(long itemCount) {
			this.itemCount = itemCount;
			}

			public long getTotal() {
			return total;
			}

			public void setTotal(long total) {
			this.total = total;
			}

			public java.sql.Timestamp getCreatedAt() {
			return createdAt;
			}

			public void setCreatedAt(java.sql.Timestamp createdAt) {
			this.createdAt = createdAt;
			}
	}
